--------------------
Snippet: sitemapFriend
--------------------
Version: 1.0.0-beta3
Created: November 16, 2010
Updated: April 2, 2012
Author: Mihai Șucan <mihai.sucan@gmail.com> (robodesign.ro)
Author: Jérôme Perrin <hello@jeromeperrin.com>

- Based on GoogleSiteMap by Shaun McCormick <shaun@modx.com>

This snippet allows you to generate maps for your web site, in HTML, XML and
other formats.

Examples:
[[!sitemapFriend &type=`html`]]
[[!sitemapFriend &type=`xml`]]

Documentation:
http://github.com/mihaisucan/sitemapFriend/wiki/
